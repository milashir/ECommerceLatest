﻿using System;

namespace Core
{
    public class Class1
    {
    }
}
