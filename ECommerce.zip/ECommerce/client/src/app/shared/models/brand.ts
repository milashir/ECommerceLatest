

export interface IBrand {
  id: number;
  name: string;
}
